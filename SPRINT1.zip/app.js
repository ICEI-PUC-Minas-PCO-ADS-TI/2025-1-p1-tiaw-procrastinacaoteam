
const informacoes = [
    {
        pontos: 500,
        semanas: 3,

        tarefas: [
            {
                id: 20,
                tipo:'concluídas',
                itens: [
                    {"id": 1, "tarefa": "Arrumar o carro"},
                    {"id": 2, "tarefa": "Lavar vasilhas"},
                    {"id": 3, "tarefa": "Estudar DIW"},
                    {"id": 4, "tarefa": "Consertar geladeira"},
                    {"id": 5, "tarefa": "Ir para a academia"}
                ]
            },
            {
                id: 30,
                tipo:'pendentes',
                itens: [
                    {"id": 6, "tarefa": "Lavar o banheiro"},
                    {"id": 7, "tarefa": "Enviar relatório mensal"},
                    {"id": 8, "tarefa": "Comprar ingredientes"},
                    {"id": 9, "tarefa": "Organizar gavetas"},
                    {"id": 10, "tarefa": "Remarcar consulta"}
                    

                ]
            }
        ]
    }
]

